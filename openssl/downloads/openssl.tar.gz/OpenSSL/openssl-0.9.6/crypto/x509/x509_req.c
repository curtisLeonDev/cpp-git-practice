/* crypto/x509/x509_req.c */
/* Copyright (C) 1995-1998 Eric Young (eay@cryptsoft.com)
 * All rights reserved.
 *
 * This package is an SSL implementation written
 * by Eric Young (eay@cryptsoft.com).
 * The implementation was written so as to conform with Netscapes SSL.
 * 
 * This library is free for commercial and non-commercial use as long as
 * the following conditions are aheared to.  The following conditions
 * apply to all code found in this distribution, be it the RC4, RSA,
 * lhash, DES, etc., code; not just the SSL code.  The SSL documentation
 * included with this distribution is covered by the same copyright terms
 * except that the holder is Tim Hudson (tjh@cryptsoft.com).
 * 
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.
 * If this package is used in a product, Eric Young should be given attribution
 * as the author of the parts of the library used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    "This product includes cryptographic software written by
 *     Eric Young (eay@cryptsoft.com)"
 *    The word 'cryptographic' can be left out if the rouines from the library
 *    being used are not cryptographic related :-).
 * 4. If you include any Windows specific code (or a derivative thereof) from 
 *    the apps directory (application code) you must include an acknowledgement:
 *    "This product includes software written by Tim Hudson (tjh@cryptsoft.com)"
 * 
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * 
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#include <stdio.h>
#include "cryptlib.h"
#include <openssl/bn.h>
#include <openssl/evp.h>
#include <openssl/asn1.h>
#include <openssl/x509.h>
#include <openssl/objects.h>
#include <openssl/buffer.h>
#include <openssl/pem.h>

X509_REQ *X509_to_X509_REQ(X509 *x, EVP_PKEY *pkey, const EVP_MD *md)
	{
	X509_REQ *ret;
	X509_REQ_INFO *ri;
	int i;
	EVP_PKEY *pktmp;

	ret=X509_REQ_new();
	if (ret == NULL)
		{
		X509err(X509_F_X509_TO_X509_REQ,ERR_R_MALLOC_FAILURE);
		goto err;
		}

	ri=ret->req_info;

	ri->version->length=1;
	ri->version->data=(unsigned char *)OPENSSL_malloc(1);
	if (ri->version->data == NULL) goto err;
	ri->version->data[0]=0; /* version == 0 */

	if (!X509_REQ_set_subject_name(ret,X509_get_subject_name(x)))
		goto err;

	pktmp = X509_get_pubkey(x);
	i=X509_REQ_set_pubkey(ret,pktmp);
	EVP_PKEY_free(pktmp);
	if (!i) goto err;

	if (pkey != NULL)
		{
		if (!X509_REQ_sign(ret,pkey,md))
			goto err;
		}
	return(ret);
err:
	X509_REQ_free(ret);
	return(NULL);
	}

EVP_PKEY *X509_REQ_get_pubkey(X509_REQ *req)
	{
	if ((req == NULL) || (req->req_info == NULL))
		return(NULL);
	return(X509_PUBKEY_get(req->req_info->pubkey));
	}

/* It seems several organisations had the same idea of including a list of
 * extensions in a certificate request. There are at least two OIDs that are
 * used and there may be more: so the list is configurable.
 */

static int ext_nid_list[] = { NID_ms_ext_req, NID_ext_req, NID_undef};

static int *ext_nids = ext_nid_list;

int X509_REQ_extension_nid(int req_nid)
{
	int i, nid;
	for(i = 0; ; i++) {
		nid = ext_nids[i];
		if(nid == NID_undef) return 0;
		else if (req_nid == nid) return 1;
	}
}

int *X509_REQ_get_extension_nids(void)
{
	return ext_nids;
}
	
void X509_REQ_set_extension_nids(int *nids)
{
	ext_nids = nids;
}

STACK_OF(X509_EXTENSION) *X509_REQ_get_extensions(X509_REQ *req)
{
	X509_ATTRIBUTE *attr;
	STACK_OF(X509_ATTRIBUTE) *sk;
	ASN1_TYPE *ext = NULL;
	int i;
	unsigned char *p;
	if ((req == NULL) || (req->req_info == NULL))
		return(NULL);
	sk=req->req_info->attributes;
        if (!sk) return NULL;
	for(i = 0; i < sk_X509_ATTRIBUTE_num(sk); i++) {
		attr = sk_X509_ATTRIBUTE_value(sk, i);
		if(X509_REQ_extension_nid(OBJ_obj2nid(attr->object))) {
			if(attr->set && sk_ASN1_TYPE_num(attr->value.set))
				ext = sk_ASN1_TYPE_value(attr->value.set, 0);
			else ext = attr->value.single;
			break;
		}
	}
	if(!ext || (ext->type != V_ASN1_SEQUENCE)) return NULL;
	p = ext->value.sequence->data;
	return d2i_ASN1_SET_OF_X509_EXTENSION(NULL, &p,
			ext->value.sequence->length,
			d2i_X509_EXTENSION, X509_EXTENSION_free,
			V_ASN1_SEQUENCE, V_ASN1_UNIVERSAL);
}

/* Add a STACK_OF extensions to a certificate request: allow alternative OIDs
 * in case we want to create a non standard one.
 */

int X509_REQ_add_extensions_nid(X509_REQ *req, STACK_OF(X509_EXTENSION) *exts,
				int nid)
{
	unsigned char *p = NULL, *q;
	long len;
	ASN1_TYPE *at = NULL;
	X509_ATTRIBUTE *attr = NULL;
	if(!(at = ASN1_TYPE_new()) ||
		!(at->value.sequence = ASN1_STRING_new())) goto err;

	at->type = V_ASN1_SEQUENCE;
	/* Generate encoding of extensions */
	len = i2d_ASN1_SET_OF_X509_EXTENSION(exts, NULL, i2d_X509_EXTENSION,
			V_ASN1_SEQUENCE, V_ASN1_UNIVERSAL, IS_SEQUENCE);
	if(!(p = OPENSSL_malloc(len))) goto err;
	q = p;
	i2d_ASN1_SET_OF_X509_EXTENSION(exts, &q, i2d_X509_EXTENSION,
			V_ASN1_SEQUENCE, V_ASN1_UNIVERSAL, IS_SEQUENCE);
	at->value.sequence->data = p;
	p = NULL;
	at->value.sequence->length = len;
	if(!(attr = X509_ATTRIBUTE_new())) goto err;
	if(!(attr->value.set = sk_ASN1_TYPE_new_null())) goto err;
	if(!sk_ASN1_TYPE_push(attr->value.set, at)) goto err;
	at = NULL;
	attr->set = 1;
	attr->object = OBJ_nid2obj(nid);
	if(!sk_X509_ATTRIBUTE_push(req->req_info->attributes, attr)) goto err;
	return 1;
	err:
	if(p) OPENSSL_free(p);
	X509_ATTRIBUTE_free(attr);
	ASN1_TYPE_free(at);
	return 0;
}
/* This is the normal usage: use the "official" OID */
int X509_REQ_add_extensions(X509_REQ *req, STACK_OF(X509_EXTENSION) *exts)
{
	return X509_REQ_add_extensions_nid(req, exts, NID_ext_req);
}

/* Request attribute functions */

int X509_REQ_get_attr_count(const X509_REQ *req)
{
	return X509at_get_attr_count(req->req_info->attributes);
}

int X509_REQ_get_attr_by_NID(const X509_REQ *req, int nid,
			  int lastpos)
{
	return X509at_get_attr_by_NID(req->req_info->attributes, nid, lastpos);
}

int X509_REQ_get_attr_by_OBJ(const X509_REQ *req, ASN1_OBJECT *obj,
			  int lastpos)
{
	return X509at_get_attr_by_OBJ(req->req_info->attributes, obj, lastpos);
}

X509_ATTRIBUTE *X509_REQ_get_attr(const X509_REQ *req, int loc)
{
	return X509at_get_attr(req->req_info->attributes, loc);
}

X509_ATTRIBUTE *X509_REQ_delete_attr(X509_REQ *req, int loc)
{
	return X509at_delete_attr(req->req_info->attributes, loc);
}

int X509_REQ_add1_attr(X509_REQ *req, X509_ATTRIBUTE *attr)
{
	if(X509at_add1_attr(&req->req_info->attributes, attr)) return 1;
	return 0;
}

int X509_REQ_add1_attr_by_OBJ(X509_REQ *req,
			ASN1_OBJECT *obj, int type,
			unsigned char *bytes, int len)
{
	if(X509at_add1_attr_by_OBJ(&req->req_info->attributes, obj,
				type, bytes, len)) return 1;
	return 0;
}

int X509_REQ_add1_attr_by_NID(X509_REQ *req,
			int nid, int type,
			unsigned char *bytes, int len)
{
	if(X509at_add1_attr_by_NID(&req->req_info->attributes, nid,
				type, bytes, len)) return 1;
	return 0;
}

int X509_REQ_add1_attr_by_txt(X509_REQ *req,
			char *attrname, int type,
			unsigned char *bytes, int len)
{
	if(X509at_add1_attr_by_txt(&req->req_info->attributes, attrname,
				type, bytes, len)) return 1;
	return 0;
}
